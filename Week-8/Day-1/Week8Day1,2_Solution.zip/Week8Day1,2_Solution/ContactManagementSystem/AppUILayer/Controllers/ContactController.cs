﻿using DataAccessLayer.Models;
using DataAccessLayer.Repository;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace AppUILayer.Controllers
{
    [Route("Contact")]
    public class ContactController : Controller
    {
        private readonly IContactRepository _contactRepository;

        public ContactController(IContactRepository contactRepository)
        {
            _contactRepository = contactRepository;
        }

        [Route("")]
        [Route("ShowContacts")]
        public IActionResult ShowContacts()
        {
            var contacts = _contactRepository.GetAllContacts();

            return View(contacts);
        }

        [Route("GetContactById/{id}")]
        public IActionResult GetContactById(int id)
        {
            var contact = _contactRepository.GetContactById(id);

            if (contact == null)
            {
                return NotFound();
            }

            return View(contact);
        }

        [HttpGet]
        [Route("AddContact")]
        public IActionResult AddContact()
        {
            LoadDropdowns();

            return View();
        }

        [HttpPost]
        [Route("AddContact")]
        public IActionResult AddContact(ContactInfo contact)
        {
            if (ModelState.IsValid)
            {
                _contactRepository.AddContact(contact);

                return RedirectToAction("ShowContacts");
            }

            LoadDropdowns();

            return View(contact);
        }

        [HttpGet]
        [Route("EditContact/{id}")]
        public IActionResult EditContact(int id)
        {
            var contact = _contactRepository.GetContactById(id);

            if (contact == null)
            {
                return NotFound();
            }

            LoadDropdowns();

            return View(contact);
        }

        [HttpPost]
        [Route("EditContact")]
        public IActionResult EditContact(ContactInfo contact)
        {
            if (ModelState.IsValid)
            {
                _contactRepository.UpdateContact(contact);

                return RedirectToAction("ShowContacts");
            }

            LoadDropdowns();

            return View(contact);
        }

        [HttpGet]
        [Route("DeleteContact/{id}")]
        public IActionResult DeleteContact(int id)
        {
            var contact = _contactRepository.GetContactById(id);

            if (contact == null)
            {
                return NotFound();
            }

            return View(contact);
        }

        [HttpPost]
        [Route("DeleteConfirmed/{id}")]
        public IActionResult DeleteConfirmed(int id)
        {
            _contactRepository.DeleteContact(id);

            return RedirectToAction("ShowContacts");
        }

        private void LoadDropdowns()
        {
            ViewBag.Companies = new SelectList(
                _contactRepository.GetCompanies(),
                "CompanyId",
                "CompanyName"
            );

            ViewBag.Departments = new SelectList(
                _contactRepository.GetDepartments(),
                "DepartmentId",
                "DepartmentName"
            );
        }
    }
}