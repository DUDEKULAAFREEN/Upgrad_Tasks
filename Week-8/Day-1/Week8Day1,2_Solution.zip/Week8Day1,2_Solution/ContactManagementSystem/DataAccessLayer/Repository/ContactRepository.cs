﻿using Dapper;
using DataAccessLayer.DbConnectionFactory;
using DataAccessLayer.Models;

namespace DataAccessLayer.Repository
{
    public class ContactRepository : IContactRepository
    {
        private readonly DapperContext _context;

        public ContactRepository(DapperContext context)
        {
            _context = context;
        }

        public List<ContactInfo> GetAllContacts()
        {
            string query = @"
                SELECT 
                    c.ContactId,
                    c.FirstName,
                    c.LastName,
                    c.EmailId,
                    c.MobileNo,
                    c.Designation,
                    c.CompanyId,
                    c.DepartmentId,
                    co.CompanyName,
                    d.DepartmentName
                FROM ContactInfo c
                INNER JOIN Company co ON c.CompanyId = co.CompanyId
                INNER JOIN Department d ON c.DepartmentId = d.DepartmentId
                ORDER BY c.ContactId DESC";

            using var connection = _context.CreateConnection();

            return connection.Query<ContactInfo>(query).ToList();
        }

        public ContactInfo? GetContactById(int id)
        {
            string query = @"
                SELECT 
                    c.ContactId,
                    c.FirstName,
                    c.LastName,
                    c.EmailId,
                    c.MobileNo,
                    c.Designation,
                    c.CompanyId,
                    c.DepartmentId,
                    co.CompanyName,
                    d.DepartmentName
                FROM ContactInfo c
                INNER JOIN Company co ON c.CompanyId = co.CompanyId
                INNER JOIN Department d ON c.DepartmentId = d.DepartmentId
                WHERE c.ContactId = @ContactId";

            using var connection = _context.CreateConnection();

            return connection.QueryFirstOrDefault<ContactInfo>(query, new { ContactId = id });
        }

        public void AddContact(ContactInfo contact)
        {
            string query = @"
                INSERT INTO ContactInfo
                (
                    FirstName,
                    LastName,
                    EmailId,
                    MobileNo,
                    Designation,
                    CompanyId,
                    DepartmentId
                )
                VALUES
                (
                    @FirstName,
                    @LastName,
                    @EmailId,
                    @MobileNo,
                    @Designation,
                    @CompanyId,
                    @DepartmentId
                )";

            using var connection = _context.CreateConnection();

            connection.Execute(query, contact);
        }

        public void UpdateContact(ContactInfo contact)
        {
            string query = @"
                UPDATE ContactInfo
                SET
                    FirstName = @FirstName,
                    LastName = @LastName,
                    EmailId = @EmailId,
                    MobileNo = @MobileNo,
                    Designation = @Designation,
                    CompanyId = @CompanyId,
                    DepartmentId = @DepartmentId
                WHERE ContactId = @ContactId";

            using var connection = _context.CreateConnection();

            connection.Execute(query, contact);
        }

        public void DeleteContact(int id)
        {
            string query = "DELETE FROM ContactInfo WHERE ContactId = @ContactId";

            using var connection = _context.CreateConnection();

            connection.Execute(query, new { ContactId = id });
        }

        public List<Company> GetCompanies()
        {
            string query = "SELECT CompanyId, CompanyName FROM Company";

            using var connection = _context.CreateConnection();

            return connection.Query<Company>(query).ToList();
        }

        public List<Department> GetDepartments()
        {
            string query = "SELECT DepartmentId, DepartmentName FROM Department";

            using var connection = _context.CreateConnection();

            return connection.Query<Department>(query).ToList();
        }
    }
}