var builder = WebApplication.CreateBuilder(args);

builder.Services.AddControllersWithViews();

// Register service
builder.Services.AddSingleton<ContactManagementDIApp.Services.IContactService,
                              ContactManagementDIApp.Services.ContactService>();

var app = builder.Build();

app.UseStaticFiles();
app.UseRouting();

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Contact}/{action=ShowContacts}/{id?}");

app.Run();