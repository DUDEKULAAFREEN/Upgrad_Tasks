﻿using ContactManagementDIApp.Models;

namespace ContactManagementDIApp.Services
{
    public interface IContactService
    {
        List<ContactInfo> GetAllContacts();

        // FIX: nullable return type
        ContactInfo? GetContactById(int id);

        void AddContact(ContactInfo contact);
    }
}