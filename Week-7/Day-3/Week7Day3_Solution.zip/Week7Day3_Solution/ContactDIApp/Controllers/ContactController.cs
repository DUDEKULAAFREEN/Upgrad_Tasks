﻿using Microsoft.AspNetCore.Mvc;
using ContactManagementDIApp.Models;
using ContactManagementDIApp.Services;

namespace ContactManagementDIApp.Controllers
{
    [Route("[controller]/[action]")]
    public class ContactController : Controller
    {
        private readonly IContactService _contactService;

        // Constructor Injection
        public ContactController(IContactService contactService)
        {
            _contactService = contactService;
        }

        // Show all contacts
        [HttpGet]
        public IActionResult ShowContacts()
        {
            var contacts = _contactService.GetAllContacts();
            return View(contacts);
        }

        // Search by ID
        [HttpGet]
        public IActionResult GetContactById(int id)
        {
            var contact = _contactService.GetContactById(id);
            return View(contact);
        }

        // GET Add
        [HttpGet]
        public IActionResult AddContact()
        {
            return View();
        }

        // POST Add
        [HttpPost]
        public IActionResult AddContact(ContactInfo contactInfo)
        {
            _contactService.AddContact(contactInfo);
            return RedirectToAction("ShowContacts");
        }
    }
}