﻿using Microsoft.AspNetCore.Mvc;
using ContactManagementApp.Models;

namespace ContactManagementApp.Controllers
{
    [Route("[controller]/[action]")]
    public class ContactController : Controller
    {
        private static List<ContactInfo> contacts = new List<ContactInfo>
        {
            new ContactInfo
            {
                ContactId = 1,
                FirstName = "Afreen",
                LastName = "Dudekula",
                CompanyName = "ABC Infotech",
                EmailId = "afreen@gmail.com",
                MobileNo = 9876543210,
                Designation = "Developer"
            },
            new ContactInfo
            {
                ContactId = 2,
                FirstName = "Sara",
                LastName = "Khan",
                CompanyName = "XYZ Solutions",
                EmailId = "sara@gmail.com",
                MobileNo = 9123456780,
                Designation = "Manager"
            }
        };

        [HttpGet]
        public ActionResult ShowContacts()
        {
            return View(contacts);
        }

        [HttpGet]
        public ActionResult GetContactById(int id)
        {
            var contact = contacts.FirstOrDefault(c => c.ContactId == id);
            return View(contact);
        }

        [HttpGet]
        public ActionResult AddContact()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult AddContact(ContactInfo contactInfo)
        {
            if (ModelState.IsValid)
            {
                contacts.Add(contactInfo);
                return RedirectToAction("ShowContacts");
            }

            return View(contactInfo);
        }
    }
}