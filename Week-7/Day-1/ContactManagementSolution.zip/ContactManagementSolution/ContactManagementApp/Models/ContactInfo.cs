﻿using System.ComponentModel.DataAnnotations;

namespace ContactManagementApp.Models
{
    public class ContactInfo
    {
        public int ContactId { get; set; }

        [Required]
        public string? FirstName { get; set; }

        [Required]
        public string? LastName { get; set; }

        [Required]
        public string? CompanyName { get; set; }

        [Required]
        [EmailAddress]
        public string? EmailId { get; set; }

        public long MobileNo { get; set; }

        [Required]
        public string? Designation { get; set; }
    }
}