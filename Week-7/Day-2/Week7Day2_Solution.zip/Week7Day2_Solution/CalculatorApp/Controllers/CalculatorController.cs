﻿using Microsoft.AspNetCore.Mvc;

namespace CalculatorApp.Controllers
{
    [Route("[controller]/[action]")]
    public class CalculatorController : Controller
    {
        // GET: Show form
        [HttpGet]
        public IActionResult Index()
        {
            return View();
        }

        // POST: Perform addition
        [HttpPost]
        public IActionResult Index(int num1, int num2)
        {
            int result = num1 + num2;

            ViewData["Result"] = result;

            return View();
        }
    }
}