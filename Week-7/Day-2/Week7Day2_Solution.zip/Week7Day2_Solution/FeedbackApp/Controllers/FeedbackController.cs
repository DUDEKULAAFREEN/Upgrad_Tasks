﻿using Microsoft.AspNetCore.Mvc;

namespace FeedbackApp.Controllers
{
    [Route("[controller]/[action]")]
    public class FeedbackController : Controller
    {
        // GET: Show form
        [HttpGet]
        public IActionResult Index()
        {
            return View();
        }

        // POST: Handle feedback
        [HttpPost]
        public IActionResult Index(string name, string comments, int rating)
        {
            string message;

            if (rating >= 4)
            {
                message = "Thank you for your feedback!";
            }
            else
            {
                message = "We will improve based on your feedback.";
            }

            ViewData["Message"] = message;

            return View();
        }
    }
}