﻿using Microsoft.AspNetCore.Mvc;

namespace StudentRegistrationApp.Controllers
{
    [Route("[controller]/[action]")]
    public class StudentController : Controller
    {
        // GET: Display Form
        [HttpGet]
        public IActionResult Register()
        {
            return View();
        }

        // POST: Handle Form Submission
        [HttpPost]
        public IActionResult Register(string studentName, int age, string course)
        {
            // Store data using ViewBag
            ViewBag.Name = studentName;
            ViewBag.Age = age;
            ViewBag.Course = course;

            // Redirect to Display page
            return View("Display");
        }

        // GET: Display Data
        [HttpGet]
        public IActionResult Display()
        {
            return View();
        }
    }
}