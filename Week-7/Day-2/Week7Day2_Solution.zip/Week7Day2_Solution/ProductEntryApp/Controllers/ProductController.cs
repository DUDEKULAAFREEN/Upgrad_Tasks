﻿using Microsoft.AspNetCore.Mvc;

namespace ProductEntryApp.Controllers
{
    [Route("[controller]/[action]")]
    public class ProductController : Controller
    {
        // Static list to store products
        private static List<dynamic> products = new List<dynamic>();

        // GET: Show form + list
        [HttpGet]
        public IActionResult Index()
        {
            ViewBag.Products = products;
            return View();
        }

        // POST: Add product
        [HttpPost]
        public IActionResult Index(string productName, double price, int quantity)
        {
            var product = new
            {
                ProductName = productName,
                Price = price,
                Quantity = quantity
            };

            products.Add(product);

            ViewBag.Products = products;

            return View();
        }
    }
}